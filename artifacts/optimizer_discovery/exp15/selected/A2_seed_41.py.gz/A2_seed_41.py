import random
import math

def propose(history, bounds, seed):
    """
    Optimize an unknown black-box function over finite bounds.
    Strategy: hybrid of low-discrepancy (Halton) global exploration,
    local refinement around the best point, and a cautious quadratic
    model fit when enough data is available.
    """
    d = len(bounds)
    rng = random.Random(seed + len(history))

    # ---------- helper: Halton sequence ----------
    def halton(index, base):
        """Return the index-th Halton number (1D) with given base."""
        result = 0.0
        f = 1.0
        i = index + 1
        while i > 0:
            f /= base
            result += f * (i % base)
            i //= base
        return result

    def halton_point(index):
        bases = [2, 3, 5, 7, 11, 13, 17, 19][:d]
        return [
            low + halton(index, base) * (high - low)
            for low, high, base in zip([b[0] for b in bounds], [b[1] for b in bounds], bases)
        ]

    # ---------- helper: solve linear system (Gauss-Jordan with pivoting) ----------
    def solve_linear(A, b_vec):
        n = len(b_vec)
        aug = [row[:] + [b_vec[i]] for i, row in enumerate(A)]
        for i in range(n):
            # partial pivoting
            max_row = max(range(i, n), key=lambda r: abs(aug[r][i]))
            if abs(aug[max_row][i]) < 1e-12:
                return None
            aug[i], aug[max_row] = aug[max_row], aug[i]
            pivot = aug[i][i]
            for j in range(i, n + 1):
                aug[i][j] /= pivot
            for r in range(n):
                if r != i:
                    factor = aug[r][i]
                    for j in range(i, n + 1):
                        aug[r][j] -= factor * aug[i][j]
        return [aug[i][n] for i in range(n)]

    # ---------- helper: quadratic model fit ----------
    def quadratic_fit(history):
        p = 1 + d + d * (d + 1) // 2
        if len(history) < p + 2:
            return None, None
        A = []
        y = []
        for row in history:
            x = row["x"]
            feats = [1.0] + list(x) + [x[i] * x[j] for i in range(d) for j in range(i, d)]
            A.append(feats)
            y.append(row["value"])
        n = len(A)
        # normal equations with ridge
        AtA = [[0.0] * p for _ in range(p)]
        Aty = [0.0] * p
        for i in range(n):
            for r in range(p):
                Aty[r] += A[i][r] * y[i]
                for c in range(p):
                    AtA[r][c] += A[i][r] * A[i][c]
        lam = 1e-6
        for r in range(p):
            AtA[r][r] += lam
        w = solve_linear(AtA, Aty)
        if w is None:
            return None, None
        return w, p

    def quadratic_stationary(w, p):
        """Return stationary point (clipped) and predicted value, or (None, None)."""
        b = w[1:1 + d]
        C = [[0.0] * d for _ in range(d)]
        idx = 1 + d
        for i in range(d):
            for j in range(i, d):
                val = w[idx]
                if i == j:
                    C[i][i] = val
                else:
                    C[i][j] = val / 2.0
                    C[j][i] = val / 2.0
                idx += 1
        rhs = [-0.5 * bi for bi in b]
        x_star = solve_linear(C, rhs)
        if x_star is None:
            return None, None
        # clip to bounds
        x_clipped = [min(max(low, x), high) for x, (low, high) in zip(x_star, bounds)]
        # predicted value at clipped point
        feats = [1.0] + list(x_clipped) + [x_clipped[i] * x_clipped[j] for i in range(d) for j in range(i, d)]
        f_pred = sum(wi * fi for wi, fi in zip(w, feats))
        return x_clipped, f_pred

    # ---------- main logic ----------
    if not history:
        return halton_point(0)   # deterministic first point

    best = min(history, key=lambda row: row["value"])["x"]
    best_val = min(row["value"] for row in history)

    t = len(history) / 31.0      # progress toward 32 evaluations

    # probability of using a Halton point for exploration
    p_halton = 0.5 - 0.4 * t     # decreases from 0.5 to 0.1

    # local step scale (shrinks with time)
    scale = 0.3 / (1.0 + t * 4.0) ** 0.5

    # quadratic candidate if data enough
    w, p = quadratic_fit(history)
    if w is not None and len(history) >= p + 2:
        x_quad, f_pred = quadratic_stationary(w, p)
        if x_quad is not None and f_pred < best_val - 1e-8:
            # use with probability 0.5, else fall through
            if rng.random() < 0.5:
                # small random perturbation to avoid exact repeats
                pert = [rng.gauss(0, 0.05 * (hi - lo)) for lo, hi in bounds]
                return [min(max(low, xi), high) for xi, (low, high) in zip(
                    [xq + p_q for xq, p_q in zip(x_quad, pert)], bounds)]

    # exploration vs local refinement
    if rng.random() < p_halton:
        return halton_point(len(history))

    # local step around best
    step_type = rng.random()
    if step_type < 0.8:
        # normal perturbation
        return [
            max(low, min(high, x + rng.gauss(0.0, scale * (high - low))))
            for x, (low, high) in zip(best, bounds)
        ]
    else:
        # occasional larger jump (Cauchy-like via ratio of normals)
        jump = rng.gauss(0, 1.0) / (rng.gauss(0, 1.0) + 1e-12)
        return [
            max(low, min(high, x + jump * 0.1 * scale * (high - low)))
            for x, (low, high) in zip(best, bounds)
        ]
