def propose(history, bounds, seed):
    import random

    dim = len(bounds)
    n = len(history)

    # Low-discrepancy Halton exploration for the first 2*dim points
    explore_count = 2 * dim
    if n < explore_count:
        primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
        idx = n + 1
        point = []
        for i in range(dim):
            base = primes[i]
            v = 0.0
            denom = 1.0
            q = idx
            while q > 0:
                q, rem = divmod(q, base)
                denom *= base
                v += rem / denom
            low, high = bounds[i]
            point.append(low + (high - low) * v)
        return point

    rng = random.Random(seed + n)

    # Sort by objective value
    sorted_hist = sorted(history, key=lambda row: row["value"])
    best_x = sorted_hist[0]["x"]
    best_val = sorted_hist[0]["value"]
    second_x = sorted_hist[1]["x"] if len(sorted_hist) > 1 else best_x

    # Stagnation detection
    last_change = 0
    min_so_far = float('inf')
    for i, row in enumerate(history):
        if row["value"] < min_so_far:
            min_so_far = row["value"]
            last_change = i
    since_last = n - 1 - last_change

    # Restart probability based on stagnation
    if since_last >= 10:
        p_restart = 0.30
    elif since_last >= 6:
        p_restart = 0.15
    else:
        p_restart = 0.03

    if rng.random() < p_restart:
        return [rng.uniform(low, high) for low, high in bounds]

    # Choose base point: sometimes a good point other than the best
    if rng.random() < 0.5:
        base = best_x
    else:
        top_count = max(1, int(0.25 * n))
        base = rng.choice(sorted_hist[:top_count])["x"]

    # Adaptive step size (decreasing from 0.3 to ~0.06)
    t = n / 32.0
    sigma = 0.3 * (1.0 - 0.8 * t)
    if sigma < 0.05:
        sigma = 0.05

    # Increase step size when stuck
    if since_last > 5:
        sigma *= 1.5

    # Occasional larger jump
    if rng.random() < 0.2:
        sigma *= 3.0

    # Directional move along best→second-best line (curved‑valley exploration)
    if rng.random() < 0.3:
        alpha = rng.uniform(0.0, 1.0)
        probe = [best_x[i] + alpha * (second_x[i] - best_x[i]) for i in range(dim)]
        perturbed = [probe[i] + rng.gauss(0.0, sigma) for i in range(dim)]
        return [max(low, min(high, perturbed[i])) for i, (low, high) in enumerate(bounds)]

    # Otherwise use Gaussian perturbation, sometimes on a single coordinate
    if rng.random() < 0.3:
        idx = rng.randrange(dim)
        low, high = bounds[idx]
        val = base[idx] + rng.gauss(0.0, sigma * (high - low))
        point = list(base)
        point[idx] = max(low, min(high, val))
        return point

    # Full‑dimensional Gaussian step
    return [
        max(low, min(high, base[i] + rng.gauss(0.0, sigma * (high - low))))
        for i, (low, high) in enumerate(bounds)
    ]
