import random
import math

def propose(history, bounds, seed):
    """
    Propose a point to evaluate next, using a simple nearest-neighbor
    surrogate with an exploration bonus that decays with the number of
    evaluations.  The method is deterministic given (history, seed).
    """
    rng = random.Random(seed + len(history))
    dim = len(bounds)

    # No history: uniform random exploration.
    if not history:
        return [rng.uniform(low, high) for low, high in bounds]

    # Normalization factors for each dimension.
    ranges = [high - low for low, high in bounds]

    # Best observed point and value.
    best = min(history, key=lambda row: row["value"])
    best_x = best["x"]
    best_val = best["value"]

    # Progress through the 32‑evaluation budget.
    progress = len(history) / 32.0

    # Exploration weight: starts high, decays to a small constant.
    lam = 0.5 * (1.0 - progress) + 0.01

    # Generate candidate points and score them.
    n_candidates = 50
    best_score = float('inf')
    best_candidate = None

    for _ in range(n_candidates):
        candidate = [rng.uniform(low, high) for low, high in bounds]

        # Find nearest observed point (Euclidean distance in normalized space).
        min_dist = float('inf')
        nearest_val = None
        for obs in history:
            dist_sq = 0.0
            for i in range(dim):
                d = (candidate[i] - obs["x"][i]) / ranges[i]
                dist_sq += d * d
            dist = math.sqrt(dist_sq)
            if dist < min_dist:
                min_dist = dist
                nearest_val = obs["value"]

        # Score = predicted value (nearest) + exploration bonus.
        score = nearest_val + lam * min_dist
        if score < best_score:
            best_score = score
            best_candidate = candidate

    # Fallback (should never happen because n_candidates > 0).
    if best_candidate is None:
        return [rng.uniform(low, high) for low, high in bounds]

    return best_candidate
